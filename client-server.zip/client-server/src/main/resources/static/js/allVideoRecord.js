var websocket = null;

//判断当前浏览器是否支持WebSocket
if ('WebSocket' in window) {
    websocket = new WebSocket("ws://127.0.0.1:15962/easyrecordHS/webSocket");
}
else {
    alert('Not support websocket')
}

//接收到消息的回调方法
websocket.onmessage = function (event) {
        stopRecord();
}
//监听窗口关闭事件，当窗口关闭时，主动去关闭websocket连接，防止连接还没断开就关闭窗口，server端会抛异常。
window.onbeforeunload = function () {
    websocket.close();
}

var recordInterval;

/**
 * 创建定时任务，半小时执行1次
 * 测试20秒走1次
 */
function setRecordInterval() {
    recordInterval = setInterval(function () {
        saveVideo();
        console.log("开始重新录制视频");
        url = videoPath + '/' + getDateTime() + '.mp4';
        newUrl=videoPath+'/'+getDateTime("time")+".mp4";
        OpenVideoAssist();
    }, 1000 * 60*30);
}

/**
 * 当采集端打开时候停止视频录制
 */
function stopRecord() {
    console.log("结束录制");
    saveVideo();
    window.clearInterval(recordInterval);
    Unload();
}

$(function () {
    $("#ok").click(function () {
        saveVideo();
    });
    setRecordInterval();
})
