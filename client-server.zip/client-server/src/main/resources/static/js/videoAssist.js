//--------------------------------高拍仪方法-------------------------------------------------

/**
 *是否添加水印
 *1代表是0代表否
 */
var isAddWk = 1;
/**
 *是否增加时间水印
 *0代表否 1是
 */
var isAddTime = 1;
/**
 *水印的类型
 *0: 文字水印, 1:图片水印
 */
var wkType = 0;
/**
 *水印出现的位置
 *0: 左上角; 1:右上角; 2:左下角; 3:右下角; 4:中间
 */
var wkPosition = 0;
/**
 *透明度控制
 *取值范围0-255
 */
var transparency = 255;
/**
 *水印图片路径, 格式支持: jpg/bmp/png/jpeg/gif
 */
var wkImagePath = 'C://1.jpg';
/**
 *水印的颜色
 */
var wkColor = 0xffff00;
/**
 *水印的字体
 */
var wkFont = '宋体';
/**
 *宽度
 */
var wkWidth = 40;
/**
 *高度
 */
var wkHeight = 40;
/**
 *是否斜体
 *0否1是
 */
var italic = 0;
/**
 * compressMode 视频压缩率, 0:高; 1:较高; 2:中等;3:较低;4:低，压缩
 * 客户端控件接口说明 压缩率越高, 文件越小，但画面质量越差。
 */
var compressMode = 3;
//水印文字
var wkText;
//视频存储位置
var videoPath;
//未加密视频文件全路径
var url;
//加密后的视频文件名称
var newUrl;
var hasLoadSuccess = 0;
var EloamGlobal;

var DeviceAssist;
var VideoAssist;
var videoCapAssist;

/**
 * 获取系统当前日期或时间
 * type =date获取日期  =time 获取时间
 * @returns 14:20:23
 */
function getDateTime(type) {
    var date = new Date();
    if (type == "date") {
        var yy = date.getFullYear().toString();
        var mm = (date.getMonth() + 1).toString();
        var dd = date.getDate().toString();
        return yy + mm + dd;
    }
    var hh = date.getHours().toString();
    var nn = date.getMinutes().toString();
    if (type=="time") {
        return hh + '-' + nn;
    }

    if(type=="datetime"){
        var yy = date.getFullYear().toString();
        var mm = (date.getMonth() + 1).toString();
        var dd = date.getDate().toString();
        return yy + mm + dd+"-"+hh+nn;
    }
    return hh + nn;
}

/**
 * 创建视频目录
 */
function createDirectory(path) {
    $.post("/easyrecordHS/createDirectory", {path: path});
};

/**
 * 保存视频
 */
function saveVideo(tmp) {
    if (videoCapAssist && videoCapAssist.VideoCapStop()) {
        videoCapAssist.Destroy();
        videoCapAssist = null;
    }
    var data = {
        oldUrl:url,
        url:newUrl
    };
    //如果为全天录则加密
    if(tmp==undefined){
        $.ajax({
            url: "/easyrecordHS/videoEncrypter",
            data: JSON.stringify(data),
            contentType: "application/json;",
            type: "post",
            success: function (result) {
                console.log("encrypter video true");
            }
        });
    }
}

function Load(tmp) {
    //获取网点名称和理财室编号,视频存储位置
    $.post("/easyrecordHS/getProperties",{"path":window.location.href}, function (result) {
        var arr = result.split(';');
        wkText = arr[0];
        if(tmp==undefined){//为空代表全天录
            videoPath = arr[1] + getDateTime("date");
            createDirectory(videoPath);
            url = videoPath +'/'+ getDateTime() + '.mp4';
            newUrl = videoPath +'/'+ getDateTime("time") + '.mp4';
        }else{
            videoPath=arr[1];
            url=videoPath + getDateTime("datetime") + '.mp4';
        }
    });
    EloamGlobal = document.getElementById("EloamGlobal_ID");
    var ret;
    try {
        ret = EloamGlobal.InitDevs();
    } catch (e) {
        //高拍仪连接成功之后给客户端监控系统发送报告
        $.post("/easyrecordHS/devstatus", {devstatus: "init_exception"});
        return;
    }
    if (ret) {
        if (!EloamGlobal.VideoCapInit()) {
            $.post("/easyrecordHS/videoRecode", {videoDevStatus: "init_fail"});
            return;
        }
        if (DeviceAssist == null) {
            $.post("/easyrecordHS/videoRecode", {videoDevStatus: "videoDev_null"});
            return;
        } else {
            $.post("/easyrecordHS/videoRecode", {videoDevStatus: "videoDev_success"});
        }
        //临时录制需要手动开始录制，全天录自动
        if(window.location.href.indexOf("all")!=-1){
            setTimeout(function () {
                OpenVideoAssist();
            }, 2000);

        }
    } else {
        $.post("/easyrecordHS/devstatus", {devstatus: "init_failed"});
        alert("连接设备失败");
    }
    hasLoadSuccess = 1;
    //  alert(videoCapAssist.VideoCapGetState());//获取当前录制状态
}

function Unload() {
    if (videoCapAssist && videoCapAssist.VideoCapStop()) {
        videoCapAssist.Destroy();
        videoCapAssist = null;
    }
    if (VideoAssist) {
        ViewAssist.SetText("", 0);
        VideoAssist.Destroy();
        VideoAssist = null;
    }
    if (videoCapAssist) {
        videoCapAssist.Destroy();
        videoCapAssist = null;
    }
    if (DeviceAssist) {
        DeviceAssist.Destroy();
        DeviceAssist = null;
    }
    if (EloamGlobal) {
        EloamGlobal.DeinitDevs();//关闭全局对象
        EloamGlobal = null;
    }

}


function AssistRecord() {
    if (VideoAssist) {
        var videoOutputWidth = 1550;
        var videoOutputHeight = 720;
        //录像时，打开视频的分辨率越低，帧率越高,一般不超过200w像素
        //所设置的帧率应尽可能高于实际帧率，避免丢帧
        var FrameRate = 15;//此参数可根据录像分辨率与机型实际帧率调节
        if (videoCapAssist) {
            videoCapAssist.VideoCapStop();
            videoCapAssist.Destroy();
        }

        videoCapAssist = EloamGlobal.CreatVideoCap();
        if (null == videoCapAssist) {
            alert("创建录像对象失败");
            return;
        }

        var selMicIdx = -1;
        if (EloamGlobal.VideoCapGetAudioDevNum() > 0)//有麦克风
        {
            selMicIdx = 0;
        } else {
            $.post("/easyrecordHS/microphone", {devstatus: "no_micphone"});
        }
        //设置视频水印
        videoCapAssist.VideoCapSetWatermark(isAddWk, isAddTime, wkType, wkPosition, transparency, wkImagePath, wkText, wkColor, wkFont, wkWidth, wkHeight, italic);
        if (!videoCapAssist.VideoCapPreCap(url, selMicIdx, FrameRate, compressMode, videoOutputWidth, videoOutputHeight)) {
            alert("启动录像失败");
            return;
        }

        if (!videoCapAssist.VideoCapAddVideoSrc(VideoAssist)) {
            alert("添加视频源失败");
            return;
        }

        if (!videoCapAssist.VideoCapStart()) {
            alert("启动录像失败");
            return;
        }
    }
}


function OpenVideoAssist() {
    CloseVideoAssist();
    if (DeviceAssist) {
        var mode = document.getElementById('selMode2');
        var modeText = mode.options[mode.options.selectedIndex].text;
        var subtype = (modeText == "YUY2" ? 1 : (modeText == "MJPG" ? 2 : (modeText == "UYVY" ? 4 : -1)));

        var select2 = document.getElementById('selRes2');
        var nResolution2 = select2.selectedIndex;

        VideoAssist = DeviceAssist.CreateVideo(2, subtype);
        if (VideoAssist) {
            // ViewAssist.SetBkColor("5,5,5");
            ViewAssist.SelectVideo(VideoAssist);
            ViewAssist.SetText("打开视频中，请等待...", 0);
            window.setTimeout(function () {
                AssistRecord();
            }, 2000);

        }
    }
}

function CloseVideoAssist() {
    if (VideoAssist) {
        VideoAssist.Destroy();
        ViewAssist.SetText("", 0);
    }
}
