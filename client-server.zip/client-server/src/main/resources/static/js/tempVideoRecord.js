$(function () {
    $("#container").height(document.documentElement.clientHeight );
    //屏幕适应
    window.onresize = function () {
        if ($(document).height() <= 500) {
             $("#container").height(document.documentElement.clientHeight);
        } else {
            $("#container").height(document.documentElement.clientHeight);
        }
    }

    $("#ok").click(function () {
        saveVideo("temp");
        Unload();
        $.get("/easyrecordHS/startRecord");
        alert("视频已保存在:"+url);
        $("#content").html("视频已录制完成，存储位置在:"+url);
    });
    $("#start").click(function () {
        $.ajax({
            url: "/easyrecordHS/stopAllDayRecord",
            type: "post",
            async: false,
            success: function (result) {
                console.log("encrypter video true");
            }
        });
        Load("temp");
        console.log("开始录制视频");
        OpenVideoAssist();
        $("#content").html("视频正在录制中");
    });
})
