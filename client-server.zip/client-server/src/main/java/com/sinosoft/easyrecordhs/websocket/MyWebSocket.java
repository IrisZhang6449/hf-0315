//package com.sinosoft.easyrecordhs.websocket;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Component;
//
//import javax.websocket.OnClose;
//import javax.websocket.OnOpen;
//import javax.websocket.Session;
//import javax.websocket.server.ServerEndpoint;
//import java.io.IOException;
//
///**
// * @author lijunming
// * @date 2018/10/10 上午11:43
// */
//@Component
//@ServerEndpoint("/webSocket")
//public class MyWebSocket {
//
//    private static  final Logger LOGGER=LoggerFactory.getLogger(MyWebSocket.class);
//
//    public static  volatile  MyWebSocket myWebSocket;
//
//    //客户端对象
//    private Session session;
//
//    @OnOpen
//    public void onOpen (Session session){
//        myWebSocket=this;
//        this.session = session;
//        LOGGER.info("webSocket open");
//    }
//
//    @OnClose
//    public void onClose(){
//        this.session=null;
//        myWebSocket=null;
//        LOGGER.info("webSocket close");
//    }
//
//    /**
//     * 向浏览器发送数据
//     * @param msg
//     */
//    public void sendMessage(String msg) {
//        try {
//            this.session.getBasicRemote().sendText(msg);
//            LOGGER.info("videoRecord is stop");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}
