package com.sinosoft.easyrecordhs.util;

import java.io.File;


/**
 * User: weihao
 * Date: 2018/8/1
 * Time: 13:59
 */
public class DiskUsageUtil {
    //获取磁盘使用率
    public static double getDiskUsage() {
        //总空间
        long allTotal = 0;
        //剩余空间
        long allFree = 0;
        for (char c = 'A'; c <= 'Z'; c++) {
            String dirName = c + ":/";
            File win = new File(dirName);
            if (win.exists()) {
                long total = (long) win.getTotalSpace();
                long free = (long) win.getFreeSpace();
                allTotal = allTotal + total;
                allFree = allFree + free;
            }
        }
        Double precent = (Double) (1 - allFree * 1.0 / allTotal) * 100;
        return precent;
    }

    public static void main(String[] args) {
        double b = getDiskUsage();
        System.out.println(b);
    }

}
