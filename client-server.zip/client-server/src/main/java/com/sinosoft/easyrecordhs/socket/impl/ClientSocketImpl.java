package com.sinosoft.easyrecordhs.socket.impl;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.service.SystemInfoService;
import com.sinosoft.easyrecordhs.socket.ClientSocket;
import com.sinosoft.easyrecordhs.util.Md5Util;
import com.sinosoft.easyrecordhs.util.StreamTool;
import com.sinosoft.easyrecordhs.util.StringUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-08-14
 * Time: 18:57
 */
@Service
public class ClientSocketImpl implements ClientSocket {

    private String SERVER_IP=Hs.prooerties.get(Hs.HOST);
    private String officeCode = Hs.prooerties.get(Hs.OFFICECODE);
    private static Logger logger = LoggerFactory.getLogger(ClientSocketImpl.class);
    private String networkName = Hs.prooerties.get(Hs.NETWORKNAME);
    private String bankShortName = Hs.prooerties.get(Hs.BANKSHORTNAME);
    private String socketPort = Hs.prooerties.get(Hs.SOCKETPORT);
    private Calendar calendar = null;
    public Socket getSocket() {
        Socket socket = null;
        try {
            if (SERVER_IP!=null&&SERVER_IP.contains("hsbc")){
                SERVER_IP =  InetAddress.getByName(SERVER_IP).getHostAddress();
                logger.info("获取的服务器ip为："+SERVER_IP);
            }
            if (socketPort==null){
                logger.info("从客户端配置文件中读取socketPort值为："+socketPort);
                socketPort=8090+"";
            }
            socket = new Socket(SERVER_IP, Integer.valueOf(socketPort));
        } catch (IOException e) {
            logger.info("创建socket失败：{}",e);
        }
        return socket;
    }

    @Override
    public Map uploadFile(String contNo, String filePath) {
        //获取标记时间的毫秒值。超过则不上传
        calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY,0);
        calendar.set(Calendar.MINUTE,0);
        long time1 = calendar.getTimeInMillis();
        calendar.set(Calendar.HOUR_OF_DAY,5);
        calendar.set(Calendar.MINUTE,0);
        long time2 = calendar.getTimeInMillis();
        long now = System.currentTimeMillis();
        long target;
        if(now > time1 && now < time2){
            target = time2;
        }else {
            calendar.add(Calendar.DAY_OF_YEAR,1);
            target = calendar.getTimeInMillis();
        }
        Map map = new HashMap();
        String flag = "";
        File file = new File(filePath);
        if (!file.exists()) {
            logger.info("文件不存在");
            return null;
        }
        //获取socket对象
        Socket socket = getSocket();
        if (socket==null){
            logger.info("创建socket失败。");
            return null;
        }
        //组织参数
        String fileName = file.getName();
        String fileLength = file.length() + "";
        String md5 = Md5Util.getMD5(file);
        if (md5==null){
            logger.info("文件对象异常，生成md5为空。");
            return null;
        }
        //封装参数
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("type", "file");
        jsonObject.put("fileName", fileName);
        jsonObject.put("fileLength", fileLength);
        jsonObject.put("contNo", contNo);
        jsonObject.put("MD5", md5);
        jsonObject.put("officeCode", officeCode);
        jsonObject.put("networkName", networkName);
        jsonObject.put("bankShortName",bankShortName);
        //String localIpAddr = SystemInfoService.getLocalIpAddr();
        String localIpAddr=null;
        //ip获取
        if (localIpAddr==null||"".equals(localIpAddr)){
            try {
                localIpAddr = InetAddress.getLocalHost().getHostAddress();
                logger.info("通过InetAddress.getLocalHost().getHostAddress()获取到的ip：{}",localIpAddr);
                if (localIpAddr==null||"".equals(localIpAddr)){
                    localIpAddr = Hs.prooerties.get(Hs.MYIP);
                    logger.info("获取本地ip失败,已从配置文件中获取ip.");
                }
            } catch (IOException e) {
                logger.info("获取ip失败{}",e.getMessage());
            }
        }
        jsonObject.put("clientIP", localIpAddr);
        //开始发送信息
        OutputStream outputStream = null;
        PushbackInputStream inStream = null;
        RandomAccessFile fileOutStream = null;
        try {
            outputStream = socket.getOutputStream();
            inStream = new PushbackInputStream(socket.getInputStream());
            String message = jsonObject.toString() + "\r\n";
            //发送消息
            outputStream.write(message.getBytes());
            //获取返回消息
            String response = StreamTool.readLine(inStream);
            if (response != null){
                logger.info("接收到返回的消息为："+response);
            }
            //接收服务端返回的消息
            //解析返回消息
            JSONObject res = new JSONObject(response);
            //断点 位置
            String position = String.valueOf(res.getLong("position"));
            //根据返回消息发送文件
            fileOutStream = new RandomAccessFile(file, "r");
            fileOutStream.seek(Long.valueOf(position));
            byte[] buffer = new byte[1024 * 1024];
            int len = -1;
            long length = Long.valueOf(position);
            outputStream = socket.getOutputStream();
            while ((len = fileOutStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, len);
                length += len;
                long time = System.currentTimeMillis();
                //logger.info("是否超时" + (time > target));
                if(time > target){
                    throw new RuntimeException("超过规定时间，停止上传");
                }
            }
            response = StreamTool.readLine(inStream);
            if (response!=null&&response.contains("=")) {
                String[] responses = response.split("=");
                flag = responses[1];
                map.put(responses[0], responses[1]);
            }
        } catch (Exception e) {
            logger.info("上传socket异常",e);
        } finally {
            close(outputStream, inStream, socket);

            try {
                if(fileOutStream != null){
                    fileOutStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(!StringUtils.isEmpty(flag) && "Y".equals(flag)){
                file = new File(filePath);
                file.delete();
            }
        }
        return map;
    }

    @Override
    public boolean uploadErrorLog(String filePath, String officeCode) {
        File file = new File(filePath);
        if (!file.exists()) {
            logger.info("文件不存在");
        }
        //获取socket对象
        Socket socket = getSocket();
        if (socket==null){
            logger.info("创建socket失败。");
            return false;
        }
        //组织参数
        String fileName = file.getName();
        String fileLength = file.length() + "";
        String md5 = Md5Util.getMD5(file);
        //封装参数
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("type", "errorlog");
        jsonObject.put("fileName", fileName);
        jsonObject.put("fileLength", fileLength);
        jsonObject.put("officeCode", officeCode);
        jsonObject.put("networkName", networkName);
        String localIpAddr = SystemInfoService.getLocalIpAddr();
        // ip获取
        if (localIpAddr==null||"".equals(localIpAddr)){
            try {
                localIpAddr = InetAddress.getLocalHost().getHostAddress();
                logger.info("通过InetAddress.getLocalHost().getHostAddress()获取到的ip：{}",localIpAddr);
                if (localIpAddr==null||"".equals(localIpAddr)){
                    localIpAddr = Hs.prooerties.get(Hs.MYIP);
                    logger.info("获取本地ip失败,已从配置文件中获取ip.");

                }
            } catch (IOException e) {
                logger.info("获取ip失败{}",e.getMessage());
            }
        }
        jsonObject.put("clientIP", localIpAddr);
        jsonObject.put("userName", System.getenv("USERNAME"));
        //开始发送信息
        OutputStream outputStream = null;
        PushbackInputStream inStream = null;
        int length = 0;
        try {
            outputStream = socket.getOutputStream();
            inStream = new PushbackInputStream(socket.getInputStream());
            String message = jsonObject.toString() + "\r\n";
            //发送消息
            outputStream.write(message.getBytes());
            //获取返回消息
            String response = StreamTool.readLine(inStream);
            //解析返回消息
            JSONObject res = new JSONObject(response);
            //断点 位置
            String position = String.valueOf(res.getInt("position"));
            //根据返回消息发送文件
            RandomAccessFile fileOutStream = new RandomAccessFile(file, "r");
            fileOutStream.seek(Integer.valueOf(position));
            byte[] buffer = new byte[1024 * 1024];
            int len = -1;
            length = Integer.valueOf(position);
            outputStream = socket.getOutputStream();
            while ((len = fileOutStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, len);
                length += len;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(outputStream, inStream, socket);
            if (Integer.valueOf(fileLength)==length){
                file.delete();
                return true;
            }else {
                return false;
            }
        }
    }


    public void close(OutputStream outStream, PushbackInputStream inStream, Socket socket) {
        try {

            if (outStream != null) {
                outStream.close();
            }
            if (inStream != null) {
                inStream.close();
            }
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}