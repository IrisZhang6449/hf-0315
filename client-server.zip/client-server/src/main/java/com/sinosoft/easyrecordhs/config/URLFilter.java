package com.sinosoft.easyrecordhs.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author lijunming
 * @date 2019/1/28 上午19:00
 * 下载链接只能在一分钟内有效
 */
public class URLFilter implements Filter {

    public  static ConcurrentHashMap videoList=new ConcurrentHashMap();
    private final Logger logger = LoggerFactory.getLogger(URLFilter.class);

    @Override
    public void destroy() {
        logger.debug("UrlFilter destroy method");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String url=httpServletRequest.getRequestURI();
        String path=url.substring(url.indexOf("video")+6);
        videoList.put(path,System.currentTimeMillis());
            chain.doFilter(request, response);
    }

    @Override
    public void init(FilterConfig arg0) {
        logger.debug("UrlFilter init method");
    }

}
