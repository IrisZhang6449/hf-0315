package com.sinosoft.easyrecordhs.server;

import com.sinosoft.easyrecordhs.util.FileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by  lijunming
 * on  date 2018-10-12
 * time 18:55
 */
@Component
public class DelAllDayRecordVideo {

    private static final Logger LOGGER = LoggerFactory.getLogger(DelAllDayRecordVideo.class);
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

    //删除本地全天录超过7天的视频文件
    @Scheduled(cron = "0 0 0 * * ?")
    public void delAllDayRecordTrans() {
        LOGGER.info("start find allDayRecord  >7  in  delete");
        Long nowTime = new Date().getTime();
        String localPath = Hs.prooerties.get(Hs.ALLVIDEOPATH);
        File file = new File(localPath);
        Long fileTime;
        String videoName;
        File videoDir;
        if (file.exists()) {
            String[] tempList = file.list();
            for (int i = 0; i < tempList.length; i++) {
                try {
                    fileTime = sdf.parse(tempList[i]).getTime();
                    if (nowTime - fileTime >= 604800000) {
                        videoName = localPath + "//" + tempList[i];
                         videoDir = new File(videoName);
                        if (videoDir.isDirectory()) {
                            FileUtil.deleteDirectory(videoName, "del");
                        } else {
                            videoDir.delete();
                        }
                        LOGGER.info("delete  allDayRecordVideo {}", tempList[i]);
                    }
                } catch (Throwable tb) {
                    LOGGER.info("delete  allDayRecordVideo  throw Exception {}", tb.getMessage());
                }
            }
        }
    }

    //每晚1点删除本地空的目录文件
    @Scheduled(cron = "0 1 0 * * ?")
    public void deleteNullDir() {
        String filePath="C:\\resources\\video";
        File file = new File(filePath);
        String videoName;
        File   videoDir;
        if (file.exists()) {
            String[] tempList = file.list();
            for (int i = 0; i < tempList.length; i++) {
                videoName = filePath + "\\" + tempList[i];
                videoDir=new File(videoName);
                if(videoDir.isFile()){
                    continue;
                }
                if(videoDir.list().length==0){
                    videoDir.delete();
                }
            }
        }
    }

}
