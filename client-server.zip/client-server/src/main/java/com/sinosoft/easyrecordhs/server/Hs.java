package com.sinosoft.easyrecordhs.server;

import java.util.HashMap;

/**
 * Created by  lijunming
 * on  date 2018-08-25
 * time 10:02
 */
public class Hs {
    public final static String SERVERIP = "serverIP";//服务器IP
    public final static String HOST = "host";                //ip
    public final static String UPPLOADTASK = "uploadTask";   //上传视频的时间点
    public final static String MYIP = "myIP";
    public final static String OFFICECODE = "officeCode";    //理财室编号
    public final static String BANKCODE = "bankCode";          //网点编号
    public final static String BANKSHORTNAME = "bankShortName";//理财室网店缩写
    public final static String NETWORKNAME = "networkName";    //网点名称
    public final static String DELDAY = "delDay";              //删除视频触发天数
    public final static String DELVIDEO = "delVideo";          //删除视频定时任务触发时间
    public final static String SOCKETPORT = "socketPort";       //socket端口
    public final static String ISOPENALLDAYRECORD = "isOpenAllDayRecord";  //全天录开关
    public final static String TEMPVIDEOPATH = "tempVideoPath";//临时录存储的位置
    public final static String ALLVIDEOPATH = "allVideoPath";//全天录存储的位置
    public final static String VIDEOPATH = "videoPath";//全天录存储的位置
    public final static String KEYONE = "keyOne";            //临时录加密密钥

    public final static String VIDEOPATHTMP = "C://resources//video//";

    public final static HashMap<String, String> prooerties = new HashMap<>();
}
