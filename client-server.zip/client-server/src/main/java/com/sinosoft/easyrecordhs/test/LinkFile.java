//package com.sinosoft.easyrecordhs.test;
//
//import net.jimmc.jshortcut.JShellLink;
//
//import java.io.File;
//
//public class LinkFile {
//
//    public static void main(String[] args) {
//        /* 获取系统的自启目录 */
//        String startFolder = "";
//        String osName = System.getProperty("os.name");
//        String userHome = System.getProperty("user.home");
//        if (osName.equals("Windows 7") || osName.equals("Windows 8") || osName.equals("Windows 10")
//                || osName.equals("Windows Server 2012 R2") || osName.equals("Windows Server 2014 R2")
//                || osName.equals("Windows Server 2016")) {
//            startFolder = userHome
//                    + "\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup";
//        }
//
//        System.out.println(startFolder);
//
//        String savePath = startFolder;
//        String appName = "恒生客户端.exe";
////        String relativelyPath=System.getProperty("user.dir");
////        String exePath = relativelyPath+File.separator+"easyrecordHS.exe";
//        String exePath = "C:\\Users\\Administrator\\Desktop\\hs\\恒生客户端.exe";
//
//        System.out.println(exePath);
//
//        File file = new File(savePath+appName);
//        if (!file.exists()){//如果快捷方式不存在就创建指定的快捷方式
//            /* 创建快捷方式到系统启动目录 */
//            System.out.println(createLinkFile(savePath, appName, exePath));
//        }
//
//
//    }
//
//    /**
//     *  为指定文件创建快捷方式到指定目录下，指定文件名称为英文名称，中文会导致执行无效
//     * @param savePath
//     * @param lnkName
//     * @param exePath
//     * @return
//     */
//    public static boolean createLinkFile(String savePath, String lnkName, String exePath){
//        File exeFile = new File(exePath);
//        File saveDir = new File(savePath);
//        if (!exeFile.exists() || !saveDir.exists()){
//            System.out.println("路径或者文件为空。");
//            return false;
//        }
//        try {
//            JShellLink link = new JShellLink();
//            link.setName(lnkName);//快捷方式的名称
//            link.setFolder(savePath);//存放路径
//            link.setPath(exePath);//指向的exe
//            link.save();
//        }catch (Exception e){
//            e.printStackTrace();
//            return false;
//        }
//        return true;
//    }
//}
