package com.sinosoft.easyrecordhs.util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by  lijunming
 * on  date 2018-08-21
 * time 14:03
 */
public class FileUtil {
    private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);

    /**
     * 根据目录路径创建目录
     * @return
     */
    public static void createDirectory(String path) {
        File file = new File(path);
        //获取父目录
        File fileParent = file.getParentFile();
        //判断是否存在
        if (!fileParent.exists()) {
            //创建父目录文件
            fileParent.mkdirs();
        }
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    /**
     * 根据图片路径截取它所在目录，然后删除目录下面的所有图片
     * @param path
     * @return true  flase
     */
    public static boolean deleteDirectory(String path, String type) {
        String parentPath;
        if (type != null) {
            parentPath = path;
        } else {
            parentPath = path.substring(0, path.lastIndexOf("/") - 1);
        }

        File file = new File(parentPath);
        boolean flag = false;
        if (!file.exists()) {
            return flag;
        }
        if (!file.isDirectory()) {
            return flag;
        }
        String[] tempList = file.list();
        File temp = null;
        for (int i = 0; i < tempList.length; i++) {
            temp = new File(parentPath + "//" + tempList[i]);
            if (temp.isFile()) {
                temp.delete();
            }
        }
        flag = file.delete();
        return flag;
    }

    /**
     * 删除文件
     * @param zipPath
     * @return
     */
    public static boolean deleteFile(String zipPath) {
        File file = new File(zipPath);
        if (file.exists()) {
            boolean flag = file.delete();
            logger.info("delete file  success {}", flag);
            return flag;
        } else {
            logger.info("{} path is non-existent", zipPath);
            return false;
        }
    }

    /**
     * 如果目录存在 || 目录存在但是目录下面没有图片 succss true
     * 如果目录存在 && 目录下面有图片，success false   并返回图片拼接成的数组
     * @param path
     * @return
     */
    public static Map createPicDirectory(String path) {
        Map map = new HashMap();
        File file = new File(path);
        //获取父目录
        File fileParent = file.getParentFile();
        //判断是否存在
        if (!fileParent.exists()) {
            //创建父目录文件
            fileParent.mkdirs();
        }
        if (file.exists()) {
            String[] tempList = file.list();
            if (tempList.length == 0) {
                logger.info("pictrue Directory exists  and  pictrue file  not exists");
                map.put("success", true);
            } else {
                logger.info("pictrue Directory exists  and  pictrue file  exists");
                map.put("success", false);
                String paths = "";
                for (int i = 0; i < tempList.length; i++) {
                    if (i == 0) {
                        paths = path + "\\" + tempList[i];
                    } else {
                        paths += "," + path + "\\" + tempList[i];
                    }
                }
                paths = StringUtil.replace(paths, "\\", "//");
                map.put("paths", paths);
            }
        } else {
            logger.info("pictrue Directory not  exists mkdir path on {}", path);
            file.mkdirs();
            map.put("success", true);
        }
        return map;
    }


    public static void main(String[] args) {
        // Map map=createPicDirectory("1");
        //System.out.println(map.get("success"));
        //System.out.println(map.get("paths"));
    }
}
