package com.sinosoft.easyrecordhs.test;

import com.sinosoft.easyrecordhs.server.Hs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-07
 * Time: 15:25
 */
@Component
public class IPtest {

    private Logger logger = LoggerFactory.getLogger(IPtest.class);
//    @Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void ipTest() {

        Enumeration<NetworkInterface> networks = null;
        try {
            networks = NetworkInterface.getNetworkInterfaces();
            if (networks == null) {
                logger.info("networks  is null");
            }
            logger.info("networks {}", networks);
        } catch (SocketException e) {
            logger.info(e.getMessage());
        }
        InetAddress ip = null;
        Enumeration<InetAddress> addrs;
        while (networks.hasMoreElements()) {
            addrs = networks.nextElement().getInetAddresses();
            if (addrs == null) {
                logger.info("addrs is null");
            }
            logger.info("addrs {}", addrs);
            while (addrs.hasMoreElements()) {
                ip = addrs.nextElement();
                logger.info("ip {}", ip);
                if (ip != null && ip instanceof InetAddress && ip.isSiteLocalAddress() ) {
                    String ipadress = ip.getHostAddress();// 客户端ip
                    logger.info("ipadress {}", ipadress);
                    if (StringUtils.isEmpty(ipadress)) {
                        logger.info("ipaddress is null");
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws UnknownHostException {

        Enumeration<NetworkInterface> networks = null;
        try {
            networks = NetworkInterface.getNetworkInterfaces();
            if (networks == null) {
                System.out.println("networks  is null");
            }
            System.out.println("networks {}"+ networks);
        } catch (SocketException e) {
            System.out.println(e.getMessage());
        }
        InetAddress ip = null;
        Enumeration<InetAddress> addrs;
        while (networks.hasMoreElements()) {

            NetworkInterface ni = networks.nextElement();
            if (ni.isVirtual()) System.out.println("==="+ni.getInetAddresses());
            addrs = ni.getInetAddresses();
            if (addrs == null) {
                System.out.println("addrs is null");
            }
            while (addrs.hasMoreElements()) {
                ip = addrs.nextElement();
                if (!ip.isLoopbackAddress() && ip.isSiteLocalAddress() && ip.getHostAddress().indexOf(":")==-1) {
                    System.out.println("InetAddress ip："+ip.toString());
                    System.out.println("real IP ："+ip.toString().split("/")[1]);

                }
            }
        }

        System.out.println("+++++++++++++++++++++++++");
        InetAddress ia = InetAddress.getLocalHost();
        String s = ia.getHostAddress().toString();
        System.out.println(s);

    }

}