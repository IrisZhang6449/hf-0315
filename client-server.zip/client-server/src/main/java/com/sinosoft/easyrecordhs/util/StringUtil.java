package com.sinosoft.easyrecordhs.util;

/**
 * @author lijunming
 * @date 2018/6/22 下午4:36
 */
public class StringUtil {
    /**
     * 字符串替换函数
     *
     * @param strMain        String 原串
     * @param strFind        String 查找字符串
     * @param strReplaceWith String 替换字符串
     * @return String 替换后的字符串，如果原串为空或者为""，则返回""
     */
    public static String replace(String strMain, String strFind,
                          String strReplaceWith) {
        StringBuffer sb = new StringBuffer("");
        int startIndex = 0;
        int endIndex = 0;
        if (strMain == null || strMain.equals("")) {
            return "";
        }
        while ((endIndex = strMain.indexOf(strFind, startIndex)) > -1) {
            sb.append(strMain.substring(startIndex, endIndex));
            sb.append(strReplaceWith);
            startIndex = endIndex + strFind.length();

        }
        sb.append(strMain.substring(startIndex, strMain.length()));
        return sb.toString();
    }
}
