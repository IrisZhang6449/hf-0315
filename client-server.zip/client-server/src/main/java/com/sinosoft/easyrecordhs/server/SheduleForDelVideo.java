package com.sinosoft.easyrecordhs.server;
import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author SunYu
 * @date 2018/8/30 15:41
 * 定时删除本地视频文件
 */
@Service
public class SheduleForDelVideo implements SchedulingConfigurer {
    private static Logger logger = LoggerFactory.getLogger(SheduleForDelVideo.class);
    //定时
    private String delCron=Hs.prooerties.get(Hs.DELVIDEO);
//    @Autowired
//    private DelVideoService delVideoService;
    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.addTriggerTask(() -> {
            logger.info("schedule del video");
            Map map = new HashMap<>();
            map.put("officeCode",Hs.prooerties.get(Hs.OFFICECODE));
            map.put("day",Hs.prooerties.get(Hs.DELDAY));
            map.put("bankCode",Hs.prooerties.get(Hs.BANKCODE));
            HttpUtil.doPost(Hs.prooerties.get(Hs.SERVERIP)+"/easyRecordHS/delVideo",JSONObject.valueToString(map));
//            if(response.contains("false")){
//                logger.info("无文件需要删除");
//                return;
//            }
//            delVideoService.delNativeVideo(response);
        }, (triggerContext) -> {
            // 定时任务触发，可修改定时任务的执行周期
            CronTrigger trigger = new CronTrigger(delCron);
            Date nextExecDate = trigger.nextExecutionTime(triggerContext);
            return nextExecDate;
        });
    }
}
