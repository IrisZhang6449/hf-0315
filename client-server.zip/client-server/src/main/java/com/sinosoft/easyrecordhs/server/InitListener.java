package com.sinosoft.easyrecordhs.server;

import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.util.StringUtils;

import javax.swing.filechooser.FileSystemView;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

/**
 * Created by  lijunming
 * 容器加载前监听器
 * on  date 2018-08-25
 * time 10:42
 */
public class InitListener implements ApplicationContextInitializer<ConfigurableApplicationContext> {
    private static Logger logger = LoggerFactory.getLogger(InitListener.class);

    @Value("${video.path}")
    private String videoPath;

    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Properties prop = new Properties();
        InputStream in = null;
        InputStreamReader inp = null;
        try {
            String relativelyPath = System.getProperty("user.dir");
            String pathName = "";
            //判断是手动启动客户端服务还是壳启动服务
            if (relativelyPath.indexOf("login") != -1) {
                pathName = "../hs.properties";
            } else {
                pathName = "hs.properties";
            }
            in = new BufferedInputStream(new FileInputStream(pathName));
            inp = new InputStreamReader(in, "UTF-8");//字节流字符流转化的桥梁
            prop.load(inp);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String task = prop.getProperty(Hs.UPPLOADTASK);
        String uploadTask = "";
        if (!StringUtils.isEmpty(task)) {
            String[] splitTask = task.split("/");
            for (String res : splitTask) {
                String arr[] = res.split(":");
                if ("00".equals(arr[1])) {
                    arr[1] = "0";
                }
                uploadTask += "0 " + arr[1] + " " + arr[0] + " * * ?/";
            }
            uploadTask = uploadTask.substring(0, uploadTask.lastIndexOf("/"));
        } else {
            uploadTask = "0 0/1 * * * ?"; //测试环境
        }
        logger.info("uploadTask ==> {}", uploadTask);

        String serverIP = prop.getProperty("serverIP");
        String serArr[] = serverIP.split(":");
        Hs.prooerties.put(Hs.SERVERIP, serverIP);
        Hs.prooerties.put(Hs.HOST, serArr[1].substring(2));
        Hs.prooerties.put(Hs.UPPLOADTASK, uploadTask);
        Hs.prooerties.put(Hs.MYIP, prop.getProperty(Hs.MYIP));
        Hs.prooerties.put(Hs.OFFICECODE, prop.getProperty(Hs.OFFICECODE));
        Hs.prooerties.put(Hs.BANKCODE, prop.getProperty(Hs.BANKCODE));
        Hs.prooerties.put(Hs.BANKSHORTNAME, prop.getProperty(Hs.BANKSHORTNAME));
        Hs.prooerties.put(Hs.NETWORKNAME, prop.getProperty(Hs.NETWORKNAME));
        Hs.prooerties.put(Hs.DELDAY, prop.getProperty(Hs.DELDAY));//测试环境当天上传完删除，uat环境为3天
        Hs.prooerties.put(Hs.DELVIDEO, "0 0 0 * * ?");
        Hs.prooerties.put(Hs.SOCKETPORT, prop.getProperty(Hs.SOCKETPORT));
        Hs.prooerties.put(Hs.ISOPENALLDAYRECORD, prop.getProperty(Hs.ISOPENALLDAYRECORD));//全天录开关
        File desktopDir = FileSystemView.getFileSystemView().getHomeDirectory();
        Hs.prooerties.put(Hs.TEMPVIDEOPATH, desktopDir.getAbsolutePath() + "\\");//临时录视频存储位置
        //获取全天录视频存储位置和临时录存储路径和加密的密钥
        String result = HttpUtil.doGet(serverIP + "/easyRecordHS/clientmonitor/getRecordInfo");
        if (!StringUtils.isEmpty(result)) {
            JSONObject jsonObject = new JSONObject(result);
            Hs.prooerties.put(Hs.ALLVIDEOPATH, jsonObject.getString("allDayRecordPath"));
            Hs.prooerties.put(Hs.VIDEOPATH, jsonObject.getString("videoPath"));
            Hs.prooerties.put(Hs.KEYONE, jsonObject.getString("key1"));
        }else {
            Hs.prooerties.put(Hs.VIDEOPATH, Hs.VIDEOPATHTMP);
        }

        String dataPath = sdf.format(new Date());
        File file = new File(Hs.prooerties.get(Hs.VIDEOPATH) + dataPath);
        if (!file.exists()) {
            file.mkdir();
        }
        in = null;
        inp = null;
    }

}

