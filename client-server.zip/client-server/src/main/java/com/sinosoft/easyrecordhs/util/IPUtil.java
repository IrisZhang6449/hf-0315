package com.sinosoft.easyrecordhs.util;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class IPUtil {

    public static InetAddress getIP() throws UnknownHostException {
        return InetAddress.getLocalHost();
    }

}
