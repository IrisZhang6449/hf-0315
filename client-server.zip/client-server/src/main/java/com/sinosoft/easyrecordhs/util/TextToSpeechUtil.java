//package com.sinosoft.easyrecordhs.util;
//
//import com.jacob.activeX.ActiveXComponent;
//import com.jacob.com.Dispatch;
//import com.jacob.com.Variant;
//
///**
// * Created by ming
// * on  date 2018-07-24
// * time 14:50
// */
//public class TextToSpeechUtil {
//    static volatile ActiveXComponent ax = null;
//    //运行时输出语音内容
//    static volatile Dispatch spVoice = null;
//    static {
//        ax = new ActiveXComponent("Sapi.SpVoice");
//        spVoice = ax.getObject();
//    }
//    /**
//     * 把文本用语音读出来
//     *
//     * @param str 要朗读的文本
//     */
//    public static void start(String str) {
//        // 音量 0-100
//        ax.setProperty("Volume", new Variant(80));
//        // 语音朗读速度 -10 到 +10
//        ax.setProperty("Rate", new Variant(-1));
//        // 执行朗读
//        Dispatch.call(spVoice, "Speak", new Variant(str));
//    }
//
//    public static void stop()
//    {
//        Dispatch.call(spVoice, "Pause");
//    }
//}
