package com.sinosoft.easyrecordhs.service;

import com.alibaba.fastjson.JSONArray;
import com.sinosoft.easyrecordhs.socket.impl.ClientSocketImpl;
import com.sinosoft.easyrecordhs.util.ZipUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Map;

/**
 * @author SunYu
 * @date 2018/12/28 11:35
 */
@Service
public class UploadService {
    private Logger logger = LoggerFactory.getLogger(UploadService.class);
    private volatile boolean flag = true;
    @Autowired
    ClientSocketImpl clientSocket;
    public void upload(String data){
        if(flag){
            if("false".equals(data)){
                logger.info("没有要上传的记录!");
                return;
            }
            JSONArray js = JSONArray.parseArray(data);
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            String contNo = "";
            for(int i = 0; i < js.size(); i++){
                flag = false;
                com.alibaba.fastjson.JSONObject obj = js.getJSONObject(i);
                logger.info("upload zip {}",obj);
                contNo = obj.getString("contNo");
                String url = obj.getString("url");
                String sourcePath=url.substring(0,url.lastIndexOf("//"));
                String fileName = sourcePath.substring(sourcePath.lastIndexOf("//")+1);
                String zipPath=sourcePath.substring(0,sourcePath.lastIndexOf("/")+1);
                zipPath=zipPath.substring(0,zipPath.lastIndexOf("/")+1);
                try{
                    ZipUtil.fileToZip(sourcePath,zipPath);
                    Map result = clientSocket.uploadFile(contNo,zipPath+ fileName + ".zip");
                    logger.info(result.toString());
                    if("Y".equals(result.get("finish"))){
                        logger.info("upload success");
                    }
                }catch (Exception e){
                    logger.info("上传文件出现异常：{},保单号：{}",e,contNo);
                }
            }
            flag = true;
        }else {
            logger.info("*******上传未结束*********");
        }
    }
}
