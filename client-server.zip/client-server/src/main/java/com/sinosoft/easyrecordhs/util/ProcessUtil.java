package com.sinosoft.easyrecordhs.util;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * Created by  lijunming
 * on  date 2018-08-21
 * time 22:10
 */
public class ProcessUtil {
    public static void main(String[] args) throws  Exception {
        String relativelyPath=System.getProperty("user.dir")+"\\src\\main\\resources\\";
        //System.out.println(relativelyPath);
        //openExe(relativelyPath+"\\hull\\恒生采集端.exe");
        boolean flag=isRunning("恒生采集端.exe");
        System.out.println("进程是否存在"+flag);
        if(flag){
            killExe("恒生采集端.exe");
            System.out.println("杀死进程");
        }
        //打开1个进程
        //openExe("C:\\Users\\ming\\Desktop\\Debug\\恒生采集端.exe");
    }

    /**
     * 判断进程是否已经存在
     * @param exeName 进程名称
     * @return true存在
     */
    public static boolean isRunning(String exeName) {
        Process proc;
        try {
            proc = Runtime.getRuntime().exec("tasklist");
            BufferedReader br = new BufferedReader(new InputStreamReader(proc
                    .getInputStream(),"GB2312"));
            String info = br.readLine();
            while (info != null) {
                if (info.indexOf(exeName) >= 0) {
                    return true;
                }
                info = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(false);
        return false;
    }

    /**
     * 打开1个exe进程
     * @param exePath  电脑的绝对路径或者项目的相对路径
     * @throws Exception
     */
    public static void openExe(String exePath) throws  Exception {
            Runtime.getRuntime().exec(exePath);
    }

    /**
     * 杀死进程
     */
    public  static void killExe(String exeName) {
            try {
                Runtime.getRuntime().exec("taskkill /F /IM "+exeName);
            }catch (Throwable tb){
                tb.printStackTrace();
            }
    }

}