package com.sinosoft.easyrecordhs.crash;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.socket.ClientSocket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;

/**
 * 客户端自动式检查有没有error.log文件，有就发送给服务端，然后删除，没有就不发送
 */
@Component
public class CrashLogTask {

    private String officeCode = Hs.prooerties.get(Hs.OFFICECODE);
    private static Logger logger = LoggerFactory.getLogger(Logger.class);

    @Autowired
    ClientSocket clientSocket;

    public void sendErrorLogToServer() {
        File file = new File("C:/resources/logs/myerror.log");
        if (!file.exists()){
            logger.info("文件不存在。");
        }else if (file.length()!=0){
            // error日志有记录到error异常信息就将日志发到服务端
            boolean ret = clientSocket.uploadErrorLog(file.getPath(), officeCode);
            if (ret){
                logger.info("error日志上传完成。");
                file.delete();
            }
        }else {
            // 没有error异常信息就不需要发送日志文件
            logger.info("errorlog为空，没有error异常信息.");
        }
    }
}
