package com.sinosoft.easyrecordhs.controller;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.util.FileDesUtil;
//import com.sinosoft.easyrecordhs.util.ProcessUtil;
//import com.sinosoft.easyrecordhs.websocket.MyWebSocket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/**
 * Created by  lijunming
 * on  date 2018-10-11
 * time 11:01
 */
@Controller
public class VideoRecordController {
    private static final Logger logger = LoggerFactory.getLogger(VideoRecordController.class);
    @GetMapping("/allVideoRecord")
    public String toAllVideoRecord(){
        return "allVideoRecord";
    }

    @GetMapping("/tempVideoRecord")
    public String toTempVideoRecord(){
        return "tempVideoRecord";
    }

    /**
     * 获取水印显示的内容和视频存储的位置
     */
    @RequestMapping("/getProperties")
    @ResponseBody
    public String getNewWorkAndOfficeCode(@RequestParam("path")String path) {
        String wkText = Hs.prooerties.get(Hs.NETWORKNAME) + "\t\t\t" + Hs.prooerties.get(Hs.OFFICECODE);
        String videoPath;
        if(path.indexOf("allVideoRecord")==-1){
            videoPath=Hs.prooerties.get(Hs.TEMPVIDEOPATH);
        }else{
            videoPath=Hs.prooerties.get(Hs.ALLVIDEOPATH);
        }
        return wkText + ";" +videoPath;
    }


    /**
     * 停止全天录
     */
    @RequestMapping("/stopAllDayRecord")
    @ResponseBody
    public String end() {
//        if(MyWebSocket.myWebSocket==null){
//            logger.info("allDAyRecord   not open");
//            return "0";
//        }
//        MyWebSocket.myWebSocket.sendMessage("stop");
//        try{
//            Thread.sleep(2000L);
//            ProcessUtil.killExe("全天录.exe");
//            logger.info(" close allDAyRecord application");
//        }catch (Exception e){
//           e.printStackTrace();
//            logger.info(" close allDAyRecord  erroe={}",e.getMessage());
//        }
        return "1";
    }

    /**
     *视频加密
     */
    @RequestMapping("videoEncrypter")
    @ResponseBody
    public Map videoEncrypter(@RequestBody Map map){
        map.put("key1",Hs.prooerties.get(Hs.KEYONE));
        FileDesUtil.fileEncrypter(map);
        return map;
    }

    /**
     *临时录结束录制时候开始全天录
     */
    @RequestMapping("startRecord")
    @ResponseBody
    public  String startAllRecord(){
        String relativelyPath = System.getProperty("user.dir");
        //如果不是通过采集端唤醒的客户端，则开启全天录
        try {
            if(relativelyPath.indexOf("login") != -1){
                relativelyPath=relativelyPath.substring(0,relativelyPath.indexOf("login")-1);
            }
            if (Hs.prooerties.get(Hs.ISOPENALLDAYRECORD).equals("yes")) {
                String exeName = relativelyPath+"\\allDayRecord/全天录.exe";
                Runtime.getRuntime().exec("cmd   /c   start " +exeName);
                logger.info("stopTempRecord,open AllDayRecord  success");
            }
        }catch (Exception e){
            logger.info("stopTempRecord,open AllRecord  in erroe={}",e.getMessage());
        }
        return "1";
    }

}
