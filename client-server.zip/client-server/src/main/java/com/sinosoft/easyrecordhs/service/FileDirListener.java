package com.sinosoft.easyrecordhs.service;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

public class FileDirListener extends FileAlterationListenerAdaptor {

    private static Logger logger = LoggerFactory.getLogger(Logger.class);
    private String officeCode = Hs.prooerties.get(Hs.OFFICECODE);
    private String bankName = Hs.prooerties.get(Hs.NETWORKNAME);
    private String bankCode = Hs.prooerties.get(Hs.BANKCODE);

    @Override
    public void onFileChange(File file) {
        String fileStatus = file.getAbsolutePath()+"改变了。";
        logger.info(fileStatus);
        sendFileStatus(fileStatus);
    }

    @Override
    public void onFileCreate(File file) {
        String fileStatus = file.getAbsolutePath()+"创建了。";
        logger.info(fileStatus);
        sendFileStatus(fileStatus);

    }

    @Override
    public void onFileDelete(File file) {
        String fileStatus = file.getAbsolutePath()+"删除了。";
        logger.info(fileStatus);
        sendFileStatus(fileStatus);
    }

    @Override
    public void onDirectoryCreate(File directory) {
        String fileStatus = directory.getAbsolutePath()+"创建了。";
        logger.info(fileStatus);
        sendFileStatus(fileStatus);
    }

    @Override
    public void onDirectoryChange(File directory) {
        String fileStatus = directory.getAbsolutePath()+"修改了。";
        logger.info(fileStatus);
        sendFileStatus(fileStatus);
    }

    @Override
    public void onDirectoryDelete(File directory) {
        String fileStatus = directory.getAbsolutePath()+"删除了。";
        logger.info(fileStatus);
        sendFileStatus(fileStatus);
    }

    /**
     *
     * @param fileStatus
     * @return
     */
    public String sendFileStatus(String fileStatus){
        String url =Hs.prooerties.get(Hs.SERVERIP)+"/easyRecordHS/clientmonitor/videofileStatus";
        String localIpAddr = SystemInfoService.getLocalIpAddr();
        // ip动态获取
        if (localIpAddr==null||"".equals(localIpAddr)){
            try {
                localIpAddr = InetAddress.getLocalHost().getHostAddress();
                logger.info("通过InetAddress.getLocalHost().getHostAddress()获取到的ip：{}",localIpAddr);
                if (localIpAddr==null||"".equals(localIpAddr)){
                    localIpAddr = Hs.prooerties.get(Hs.MYIP);
                    logger.info("获取本地ip失败,已从配置文件中获取ip.");

                }
            } catch (IOException e) {
                logger.info("获取ip失败{}",e.getMessage());
            }
        }
        String username = System.getenv("USERNAME");
        JSONObject jsonObject = new JSONObject();
        String fileSta = username+"把"+fileStatus;
        jsonObject.put("videofileStatus",fileSta);
        jsonObject.put("officeIp",localIpAddr);
        jsonObject.put("officeCode",officeCode);
        jsonObject.put("bankName",bankName);
        jsonObject.put("bankCode",bankCode);
        HttpUtil.doPost(url,jsonObject.toString());
        return "";
    }

}
