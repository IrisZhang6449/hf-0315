package com.sinosoft.easyrecordhs.controller;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.util.FileUtil;
import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author SunYu
 * @date 2018/8/30 16:25
 * 删除本地视频文件
 */
@RestController
public class DelNativeVideoController {
    @RequestMapping(value = "/delNativeVideo", method = RequestMethod.POST, consumes = "application/json")
    public boolean delNativeVideo(@RequestBody String data){
        JSONObject map = new JSONObject(data);
        String url = (String)map.get("url");
        String contNo = (String)map.get("contNo");
        boolean flag = FileUtil.deleteDirectory(url,null);
        if(flag){
            Map info = new HashMap<>();
            info.put("contNo",contNo);
            //删除成功，给服务器返回数据
            HttpUtil.doPost(Hs.prooerties.get(Hs.SERVERIP)+"/easyRecordHS/updateVideo",JSONObject.valueToString(info));
            return flag;
        }else {
            return flag;
        }
    }
}
