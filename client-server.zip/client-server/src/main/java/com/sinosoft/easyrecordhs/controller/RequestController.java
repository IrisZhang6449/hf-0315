package com.sinosoft.easyrecordhs.controller;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.util.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by  lijunming
 * on  date 2018-08-08
 * time 13:07
 */
@RestController
public class RequestController {
    private static final Logger logger = LoggerFactory.getLogger(RequestController.class);

    public static Set videoList = new HashSet<String>();
     @Value("${clientVersion}")
     private String clientVersion;
    /**
     * 根据本地图片全路径，响应给浏览器1个图片流
     */
    @RequestMapping("/showImage")
    public void showImage(HttpServletResponse response, @RequestParam("fileName") String fileName) {
        show(response, fileName, "image");
    }

    /**
     * 根据本地视频全路径，响应给浏览器1个视频
     */
    @RequestMapping("/showVideo")
    public void showVideo(HttpServletResponse response, @RequestParam("fileName") String fileName) {
        videoList.add(fileName);
        show(response, fileName, "video");
    }

    /**
     * 为录像创建1个目录 11:01
     **/
    @RequestMapping("/createDirectory")
    public String createDirectory(@RequestParam("path") String path) {
        FileUtil.createDirectory(path);
        return "1";
    }

    /**
     * 为拍照图片创建路径
     *
     * @param path 图片路径
     * @return 创建返回 true,不创建返回false
     */
    @RequestMapping("/createPicDirectory")
    public String createPicDirectory(@RequestParam("path") String path) {
        Map result = FileUtil.createPicDirectory(path);
        String renderStr = "jsonpCallback" + "(" + JSONObject.valueToString(result) + ")";
        return renderStr;
    }

    //根据拍照图片的路径,返回文件流
    @RequestMapping("/uploadFile")
    public String sendInputStream(@RequestBody String data) {
        JSONObject object = new JSONObject(data);
        JSONArray arr = object.getJSONArray("filePath");
        Map resultMap = new HashMap();
        boolean success;
        try {
            //如果传输完成，把本地图片路径给删除
            success = HttpUtil.upload(arr, object.getString("contNo"));
            if (success) {
                FileUtil.deleteDirectory(arr.getString(0), null);
                logger.info("delete location pictrue   success  true");
                resultMap.put("message", "client upload  success true");
            } else {
                resultMap.put("message", "client upload  success false");
            }
        } catch (Throwable tb) {
            tb.printStackTrace();
            success = false;
            resultMap.put("message", tb.getMessage());
            logger.info("delete location pictrue   success  false");
        }
        resultMap.put("success", success);
        return JSONObject.valueToString(resultMap);
    }

    //获取理财室编号
    @RequestMapping("/getOfficeCode")
    public String getOfficeCode() {
        Map map = new HashMap();
        map.put("networkName", Hs.prooerties.get(Hs.NETWORKNAME));
        map.put("officeCode", Hs.prooerties.get(Hs.OFFICECODE));
        map.put("bankCode", Hs.prooerties.get(Hs.BANKCODE));
        map.put("clientVersion", clientVersion);
        String renderStr = "jsonpCallback" + "(" + JSONObject.valueToString(map) + ")";
        logger.info("getBankInfo {}", renderStr);
        return renderStr;
    }

    //放弃购买时删除本地视频
    @RequestMapping("/deleteVideo")
    public String deleteVideo(@RequestParam(value = "path", required = false) String path, @RequestParam(value = "newUrl", required = false) String newUrl) {
        if (!StringUtils.isEmpty(path)) {
            boolean success = FileUtil.deleteDirectory(path, null);
            logger.info("delete videoDirectory  in  path:{},success:{}", path, success);
        }
        if (!StringUtils.isEmpty(newUrl)) {
            boolean success = FileUtil.deleteFile(newUrl);
            logger.info("delete videoFile  in  path:{},success:{}", newUrl, success);
            if (success) {
                videoList.remove(newUrl);
            }
        }
        return "1";
    }

    //完成录制的时候对视频文件加密
    @RequestMapping("/fileEncrypter")
    public String encrypt(@RequestBody Map map) {
        logger.info("fileEncrypter map={}", map);
        return FileDesUtil.fileEncrypter(map);
    }

    //退出程序
    @RequestMapping("/killClient")
    public String killClient() {
        logger.info("session失效了，杀死进程");
        ProcessUtil.killExe("恒生采集端.exe");
        return "1";
    }

    /**
     * 解密文件，然后返回视频流给页面d，最后删除解密后的视频文件
     *
     * @param url    加密的录制
     * @param newUrl 新的文件
     */
    @RequestMapping("/unFileEncrypter")
    public void unFileEncrypter(@RequestParam("url") String url, @RequestParam("newUrl") String newUrl, @RequestParam("key1") String key1) {
        //第一步先解密
        FileDesUtil.unFileEncrypter(url, newUrl, key1);
    }


    /**
     * 响应文件
     *
     * @param fileName 文件全路径
     * @param type     文件类型
     */
    public void show(HttpServletResponse response, String fileName, String type) {
        try {
            FileInputStream fis = new FileInputStream(fileName);
            int i = fis.available();
            byte data[] = new byte[i];
            fis.read(data);
            response.setContentType(type + "/*");
            response.setContentLength(i);
            response.setHeader("Accept-Ranges", "bytes");
            OutputStream toClient = response.getOutputStream();
            toClient.write(data);
            toClient.flush();
            toClient.close();
            fis.close();
        } catch (Exception e) {
            logger.info("File is not found errorMessage: {}", e.getMessage());
        }
    }


}