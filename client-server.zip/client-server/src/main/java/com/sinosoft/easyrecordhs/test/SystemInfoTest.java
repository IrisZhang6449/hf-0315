package com.sinosoft.easyrecordhs.test;

public class SystemInfoTest {

    public static void main(String[] args) {
        Runtime rt = Runtime.getRuntime();
        long totle = rt.totalMemory();
        long free = rt.freeMemory();
        System.out.println("totle:"+totle/1024+"MB");
        System.out.println("free:"+free/1024+"MB");
        System.out.println("use:"+(totle-free)/1024+"MB");
        System.out.println("usage:"+(((totle-free)/1024)/(totle/1024))+"%");


    }

}
