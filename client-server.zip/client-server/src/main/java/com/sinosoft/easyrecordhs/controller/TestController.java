package com.sinosoft.easyrecordhs.controller;

import com.sinosoft.easyrecordhs.socket.impl.ClientSocketImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.UUID;

/**
 * Created by  lijunming
 * on  date 2018-08-16
 * time 11:43
 */
@Controller
@RequestMapping("/test")
public class TestController {
    @Resource
    ClientSocketImpl clientSocket;
     @RequestMapping("/index")
    public String toIndex(){
         return "index";
     }
     @ResponseBody
     @RequestMapping("/hello")
     public String hello(){
         return "hello";
     }
     @RequestMapping("/upload")
    public  String upload(@RequestParam(value ="file", required = false) MultipartFile attach){
         String fileName="";
         System.out.println("上传的文件的ContentType："+attach.getContentType());
         if (!attach.isEmpty()) {
              fileName = attach.getOriginalFilename();// 旧文件名
         }
        clientSocket.uploadFile("12212121",fileName);
            return "redirect:index?flag=1";
     }
}
