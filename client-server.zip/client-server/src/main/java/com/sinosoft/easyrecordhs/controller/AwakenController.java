package com.sinosoft.easyrecordhs.controller;
import com.sinosoft.easyrecordhs.util.ProcessUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by  lijunming
 * on  date 2018-08-21
 * time 22:14
 */
@RestController
@RequestMapping("/awaken")
public class AwakenController {
    private static final Logger logger = LoggerFactory.getLogger(AwakenController.class);
    /**
     * 唤醒本地服务
     */
    @RequestMapping("/receive")
    public  String  receive(@RequestBody String data){
        JSONObject map=new JSONObject(data);
        Map resultMap=new HashMap();
        resultMap.put("success",false);
        try {
            //判断外壳是否已打开过
            Boolean flag = ProcessUtil.isRunning("恒生采集端.exe");
            //如果存在
            if (flag) {
               resultMap.put("success",false);
               resultMap.put("message","You have already opened this application.");
                logger.info("awaken=false,You have already opened this application.");
                return JSONObject.valueToString(resultMap);
            }
             String relativelyPath=System.getProperty("user.dir");
             if(relativelyPath.indexOf("login")!=-1){
                relativelyPath=relativelyPath.substring(0,relativelyPath.indexOf("login")-1);
             }
            ProcessUtil.openExe(relativelyPath+"\\login\\恒生采集端.exe  "+map.get("agentCode"));
            resultMap.put("success",true);
            resultMap.put("message","Wake up double recording system success");
            logger.info("awaken=true,Wake up double recording system success");
        }catch (Throwable tb){
            resultMap.put("success",false);
            resultMap.put("message","Failed to wake up the double recording system. Please wake up manually.");
            logger.info("awaken=false,Failed to wake up the double recording system. Please wake up manually.");
            return JSONObject.valueToString(resultMap);
        }
            return JSONObject.valueToString(resultMap);
    }
    
}
