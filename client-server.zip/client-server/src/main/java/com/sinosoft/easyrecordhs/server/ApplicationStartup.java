package com.sinosoft.easyrecordhs.server;
import com.sinosoft.easyrecordhs.util.ProcessUtil;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 * Created by  lijunming
 * on  date 2018-08-02
 * time 20:15
 * web容器加载后监听器
 * 客户端启动了自动打开全天录制的窗体
 */
@Component
public class ApplicationStartup implements ApplicationListener<ContextRefreshedEvent> {
    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        try {
            //如果不是通过采集端唤醒的客户端，则开启全天录
            if(!ProcessUtil.isRunning("恒生采集端") && Hs.prooerties.get(Hs.ISOPENALLDAYRECORD).equals("yes")){
                String relativelyPath = System.getProperty("user.dir");
                String exeName = relativelyPath+"\\allDayRecord/全天录.exe";
                Runtime.getRuntime().exec("cmd   /c   start " +exeName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
