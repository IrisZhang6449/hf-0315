//package com.sinosoft.easyrecordhs.test;
//
//import java.io.IOException;
//
//public class WithSystemStart {
//    public static void main(String[] args) throws IOException {
//        String key="HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";
//        String name="myname";//启动项名称
//        String value="mypath";//程序路径
//        String command="reg add "+key+" /v "+name+" /d "+value;
//        Runtime.getRuntime().exec(command);
//    }
//}
