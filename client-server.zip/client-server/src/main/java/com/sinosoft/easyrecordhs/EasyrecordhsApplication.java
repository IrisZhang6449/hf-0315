package com.sinosoft.easyrecordhs;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.server.InitListener;
import com.sinosoft.easyrecordhs.crash.CrashHandler;
import com.sinosoft.easyrecordhs.service.SystemInfoService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.net.InetAddress;
import java.net.UnknownHostException;

@SpringBootApplication
@EnableScheduling
public class EasyrecordhsApplication {

    public static void main(String[] args) {
        local();
        SpringApplication app = new SpringApplication(EasyrecordhsApplication.class);
        //程序异常退出监测处理
        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler());
        /*把MyApplicationContextInitializer注入到容器中*/
        app.addInitializers(new InitListener());
        if (args.length == 0) {
            args = new String[2];
            args[0] = "-Xms100m";//堆初始化值
            args[1] = "-Xmx200m";//堆最大值
        }
        app.run(args);
    }

    public static void local() {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            String ip = addr.getHostAddress(); //获取本机ip
            String hostName = addr.getHostName(); //获取本机计算机名称
            System.out.println(ip);
            System.out.println(hostName);
            System.out.println(SystemInfoService.getLocalIPbyCMD());

//            Hs.prooerties.put(Hs.CLIENTIPTMP, ip); //客户端启动，存储一次IP记录，用于后续心跳使用

        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

    }

}
