package com.sinosoft.easyrecordhs.config;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.service.FileDirListener;
import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;

/**
 * 应用启动之后执行的任务
 */
@Component
public class FileDirListenerStartUp implements ApplicationRunner {

    private static Logger logger = LoggerFactory.getLogger(Logger.class);

    @Override
    public void run(ApplicationArguments args) throws Exception {
        //获取安装包目录，然后隐藏
//        String relativelyPath = System.getProperty("user.dir");
//        if (relativelyPath.indexOf("login") != -1) {
//            relativelyPath = relativelyPath.substring(0, relativelyPath.indexOf("login") - 1);
//        }
//        //截取到../../的路径
//        relativelyPath=relativelyPath.substring(0,relativelyPath.lastIndexOf("\\")).substring(0,relativelyPath.lastIndexOf("\\"));
//        File dis = new File(relativelyPath);
//        if (!dis.isHidden()) {
//            try {
//                Runtime.getRuntime().exec("attrib " + "\"" + dis.getAbsolutePath() + "\"" + " +H");
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }

        String url = Hs.prooerties.get(Hs.SERVERIP) + "/easyRecordHS/clientmonitor/getMonitorDIr";
        String result = HttpUtil.doGet(url);//获取视频保存的目录
        if (StringUtils.isEmpty(result)) {
            return;
        }
        JSONObject resultJson = new JSONObject(result);
        String videoSaveDir = resultJson.getString("videoPath");
        String allRecordDir = resultJson.getString("allDayRecordPath");
        if (StringUtils.isEmpty(allRecordDir)) {
            logger.info("客户端全天录视频文件保存目录为空，请检查。。");
        }else{
            //设置全天录目录隐藏
            File allRecord = new File(allRecordDir);
            if(!allRecord.isHidden()){
                try {
                    Runtime.getRuntime().exec("attrib " + "\"" + allRecord.getAbsolutePath() + "\""+ " +H");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        if (StringUtils.isEmpty(videoSaveDir)){
            logger.info("客户端视频文件保存目录为空，请检查。。");
        }else {
            // 开启 监测视频文件保存目录
           FileAlterationObserver observer = new FileAlterationObserver(videoSaveDir,null,null);
            observer.addListener(new FileDirListener());
            FileAlterationMonitor monitor = new FileAlterationMonitor(1000L,observer);
            //设置业务视频目录隐藏
            File file = new File(videoSaveDir);
            if(!file.isHidden()){
                try {
                    Runtime.getRuntime().exec("attrib " + "\"" + file.getAbsolutePath() + "\""+ " +H");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                logger.info("文件目录监测初始化中。。。");
                monitor.start();
                logger.info("文件目录监测初始化完成。");
            } catch (Exception e) {
                logger.info("目录监测异常信息"+e.getMessage());
            }
        }
    }
}
