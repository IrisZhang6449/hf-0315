package com.sinosoft.easyrecordhs.socket;

import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-08-14
 * Time: 18:57
 */
public interface ClientSocket {

    Map uploadFile(String contNo,String filePath);

    boolean uploadErrorLog(String filePath,String officeCode);
}
