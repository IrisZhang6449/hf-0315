package com.sinosoft.easyrecordhs.crash;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 捕获崩溃异常信息
 */
@Component
public class CrashHandler implements Thread.UncaughtExceptionHandler {


    // 用来存储设备信息和异常信息
    private Map<String,String> infos = new HashMap<String,String>();

    private Logger logger = LoggerFactory.getLogger(Logger.class);

    /**
     当UncaughtException发生时会转入该函数来处理 *
     */
    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        //收集信息 输出到日志中
        logger.error("UncaughtExceptionMessage:>>>");
        logger.error(ex.getMessage());
        StackTraceElement[] stackTrace = ex.getStackTrace();
        for (int i=0;i<stackTrace.length;i++){
            logger.error(stackTrace[i].toString());
        }
    }

}
