package com.sinosoft.easyrecordhs.util;

import com.sun.management.OperatingSystemMXBean;

import java.lang.management.ManagementFactory;

public class MemeoryUsageUtil {
    public static double getMemoryUsage() {
        OperatingSystemMXBean osmxb = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
        //总的物理内存+虚拟内存
        long totalvirtualMemory = osmxb.getTotalSwapSpaceSize();
        //剩余物理内存
        long freePhysicalMemorySize = osmxb.getFreePhysicalMemorySize();
        Double memoryUsage = (Double) (1 - freePhysicalMemorySize * 1.0 / totalvirtualMemory) * 100;
        return memoryUsage;
    }
}
