package com.sinosoft.easyrecordhs.service;

import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.util.*;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.*;
import java.net.*;
import java.util.*;

@Component
public class SystemInfoService {
    public static Logger logger = LoggerFactory.getLogger(Logger.class);

    private String serverIp = Hs.prooerties.get(Hs.SERVERIP);

    private String bankCode = Hs.prooerties.get(Hs.BANKCODE); //网点号
    private String networkName = Hs.prooerties.get(Hs.NETWORKNAME); //网点名称缩写
    private String bankShortName = Hs.prooerties.get(Hs.BANKSHORTNAME); //网点名称
    private String officeCode = Hs.prooerties.get(Hs.OFFICECODE); //理财室编码

    /**
     * 1分钟发送一次心跳数据
     **/
    @Scheduled(fixedDelay = 1000 * 5)
    public void clientHeart() {
        try {
            //获取本地网点信息的json对象
            JSONObject jsonObject = getSystemInfo();

            String heartinfo = jsonObject.toString() + "\r\n";

            //http方式发送心跳
            String response = HttpUtil.doPost(serverIp + "/easyRecordHS/socket", heartinfo);

            logger.info("client heart info ==> {}, response ==> {}", heartinfo, response);
        } catch (Exception e) {
            logger.info("发送心跳信息异常 ==> {}", e);
        }
    }

    /**
     * 特别消耗cpu，改成晚上1点查询1次 cpu 磁盘  内存 的利用率 和心跳信息发送到服务端去
     **/
    @Scheduled(cron = "0 0 1 * * ?")
    public void HeartSystemInfo() {
        try {
            //获取本地网点信息的json对象
            JSONObject jsonObject = getNetInfo();
            //获取本地信息
            Map<String, String> sysDevInfo = getSysDevInfo(); //本地运行环境中 cpu 磁盘 内存 的利用率
            jsonObject.put("cpuUsage", sysDevInfo.get("cpuUsage"));
            jsonObject.put("diskUsage", sysDevInfo.get("diskUsage"));
            jsonObject.put("memoryUsage", sysDevInfo.get("memoryUsage"));
            //http方式发送磁盘使用率
            String response = HttpUtil.doPost(serverIp + "/easyRecordHS/socket", jsonObject.toString());
            logger.info("磁盘信息+心跳信息 ==> {}, response ==> {}", jsonObject.toString(), response);
        } catch (Exception e) {
            logger.info("连接不上服务器了！！:{}", e);
        }
    }


    /**
     * 获取系统设备信息
     *
     * @return Map
     */
    public Map<String, String> getSysDevInfo() {
        Map<String, String> devInfo = new HashMap<>();
        logger.info("获取cpu 磁盘 内存利用率中。。");
        double cpuUsage = CpuUsageUtil.getCpuUsage();//cpu使用率
        double diskUsage = DiskUsageUtil.getDiskUsage();//磁盘使用率
        double memoryUsage = MemeoryUsageUtil.getMemoryUsage();//内存使用率
        devInfo.put("cpuUsage", cpuUsage + "");
        devInfo.put("diskUsage", diskUsage + "");
        devInfo.put("memoryUsage", memoryUsage + "");
        logger.info("获取cpu 磁盘 内存利用率完成");
        logger.info("通过ipconfig解析出的IPv4相关信息：{}", getLocalIPbyCMD());
        return devInfo;
    }


    /**
     * 获取本机 网点信息( 主机名、银行网点名称、理财室编码、客户端IP )
     *
     * @return Map
     */
    public JSONObject getNetInfo() throws UnknownHostException {
        String clientIP = SystemInfoService.getLocalIpAddr();
        if (clientIP == null || "".equals(clientIP)) {
            try {
                clientIP = InetAddress.getLocalHost().getHostAddress();
                logger.info("通过InetAddress.getLocalHost().getHostAddress()获取到的ip：{}", clientIP);
                if (clientIP == null || "".equals(clientIP)) {
                    clientIP = Hs.prooerties.get(Hs.MYIP);
                    logger.info("获取本地ip失败,已从配置文件中获取ip.");
                }
            } catch (IOException e) {
                logger.info(e.getMessage());
            }
        }

        InetAddress localHost = InetAddress.getLocalHost();
        String hostName = localHost.getHostName(); //系统主机名

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("hostname", hostName);
        jsonObject.put("clientIP", clientIP);
        jsonObject.put("bankShortName", bankShortName);
        jsonObject.put("officeCode", officeCode);
        jsonObject.put("bankCode", bankCode);
        jsonObject.put("networkName", networkName);
        jsonObject.put("type", "clientDevUsage");

        return jsonObject;
    }

    /**
     * 获取本地内网ip 如果获取不到那就返回空字符串
     *
     * @return
     */
    public static String getLocalIpAddr() {
        Enumeration<NetworkInterface> networks = null;
        try {
            networks = NetworkInterface.getNetworkInterfaces();
            if (networks == null) {
                logger.info("networks  is null");
                return null;
            }
        } catch (SocketException e) {
            logger.info(e.getMessage());
        }
        InetAddress ip = null;
        Enumeration<InetAddress> addrs;
        while (networks.hasMoreElements()) {
            addrs = networks.nextElement().getInetAddresses();
            if (addrs == null) {
                logger.info("addrs is null");
                continue;
            }
            while (addrs.hasMoreElements()) {
                ip = addrs.nextElement();
                if (ip != null && ip instanceof Inet4Address && ip.isSiteLocalAddress()) {
                    String ipadress = ip.getHostAddress(); //客户端ip
                    logger.info("local ipadress {}", ipadress);
                    if (StringUtils.isEmpty(ipadress)) {
                        logger.info("ipaddress is null");
                    } else {
                        return ipadress;
                    }
                }
            }
        }
        return null;
    }

    /**
     * 通过执行 ipconfig 命令获取ip地址
     *
     * @return
     */
    public static String getLocalIPbyCMD() {
        String localIP = null;
        Runtime runtime = Runtime.getRuntime();
        Process process = null;
        try {
            process = runtime.exec("ipconfig");
        } catch (IOException e) {
            e.printStackTrace();
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        try {
            while ((line = br.readLine()) != null) {
                if (line.contains("IPv4")) {
                    logger.info("客户端的IPv4相关信息：{}", line);
                    localIP = line.split(":")[1].trim();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                br = null;
            }
            if (localIP == null || "".equals(localIP) || localIP.split("\\.").length != 4) {
                System.out.println("客户端本地ip获取有误：" + localIP);
                return null;
            } else {
                return localIP;
            }
        }
    }

    public void close(OutputStream outStream, BufferedReader bufferedReader, Socket socket) {
        try {

            if (outStream != null) {
                outStream.close();
            }
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            socket.close();
        } catch (Exception e) {
            logger.info("关闭连接异常：{}", e);
        }
    }

    /**
     * 获取本机 网点信息( 主机名、银行网点名称、理财室编码、客户端IP )
     *
     * @return Map
     */
    public JSONObject getSystemInfo() throws UnknownHostException {
        InetAddress localHost = IPUtil.getIP();
        String clientIP = localHost.getHostAddress();
        String hostName = localHost.getHostName();

        JSONObject jsonObject = new JSONObject();

        jsonObject.put("clientIP", clientIP);
        jsonObject.put("hostname", hostName);
        jsonObject.put("bankShortName", bankShortName);
        jsonObject.put("officeCode", officeCode);
        jsonObject.put("bankCode", bankCode);
        jsonObject.put("networkName", networkName);
        jsonObject.put("type", "heart");
        return jsonObject;
    }

}
