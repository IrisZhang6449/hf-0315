package com.sinosoft.easyrecordhs.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.UUID;


/*本节是加密解密demo2*/

/**
 * 文件名：fileencrypter.java jdk：1.40以上
 * 说明：文件加密
 * 加密方法：三重des加密（des 3X16）
 * 加密过程：对选中的文件加密后在同文件夹下生成一个增加了".tdes" 扩展名的加密文件
 * 解密过程：对选中的加密文件（必须有".tdes"扩展名）进行解密
 */
public class FileDesUtil {
    private final static Logger logger = LoggerFactory.getLogger(FileDesUtil.class);
    private static final String Algorithm = "DESede"; // 定义加密算法,可用，DES,DESede,Blowfish

    /***
     *     具体操作   字母   E/e=加密；其他：解密
     *  fileName:要操作的文件名
     *                      operation     具体操作：字母：E/e=加密；其他：解密
     */
    //加密的方法
    public static String fileEncrypter(Map map) {
        String fileInName = map.get("oldUrl").toString();
        String fileOutName = map.get("url").toString();
        String key1 = map.get("key1").toString();
        //加密
        logger.info("end");
        return encrypt(fileInName, fileOutName, key1);
    }

    //56为加密算法
    public static String getUUID(int number) {//number加密长度
        if (number < 1) {
            return null;
        }
        StringBuffer retArray = new StringBuffer();
        for (int i = 0; i < number; i++) {
            retArray.append(getUUID().substring(0, 1));
        }
        return retArray.toString();
    }

    /**
     * 获得一个UUID
     *
     * @return String UUID
     */
    //40位加密算法
    public static String getUUID() {
        String uuid = UUID.randomUUID().toString();
        //去掉“-”符号
        return uuid.replaceAll("-", "");
    }

    //解密的方法
    public static String unFileEncrypter(String fileInName, String fileOutName, String key) {
        decrypt(fileInName, fileOutName, key);
        logger.info("end");
        return fileOutName;
    }

    public static String encrypt(String fileInName, String fileOutName, String key) {
        logger.info("Start the encryption operation");
        try {
            File fileIn = new File(fileInName);
            FileInputStream fis = new FileInputStream(fileIn);
            byte[] bytIn = new byte[100];
            for (int i = 0; i < 100; i++) {
                bytIn[i] = (byte) fis.read();
            }
            // 加密
            byte[] bytOut = Encrypt3DES(bytIn, key);
            logger.info("Encryption operations are underway");

            File fileOut = new File(fileOutName);

            FileOutputStream fileOutStream = new FileOutputStream(fileOut);
            for (int i = 0; i < bytOut.length; i++) {
                fileOutStream.write((int) bytOut[i]);
            }
            RandomAccessFile randomAccessFile = new RandomAccessFile(fileOut, "rwd");
            randomAccessFile.seek(bytOut.length);

            FileInputStream fileInputStream = new FileInputStream(fileIn);
            fileInputStream.skip(100);

            byte[] buffer = new byte[1024 * 1024];
            int len = -1;
            len = fileInputStream.read(buffer);
            while (len != -1) { //从输入流中读取数据写入到文件中
                fileOutStream.write(buffer, 0, len);
                len = fileInputStream.read(buffer);
            }

            randomAccessFile.close();
            fileInputStream.close();
            fis.close();
            fileOutStream.close();
            fileIn.delete();
            logger.info("Successful encryption operation");
            return "1";
        } catch (Exception e) {
            logger.info("加密失败：{}", e);
            return "-1";
        }
    }


    public static void decrypt(String fileInName, String fileOutName, String key) {
        logger.info("Start decryption operation");
        FileInputStream fis = null;
        FileOutputStream fileOutStream = null;
        RandomAccessFile randomAccessFile = null;
        FileInputStream fileInputStream = null;
        try {
            File fileIn = new File(fileInName);
            fis = new FileInputStream(fileIn);
            byte[] bytIn = new byte[104];
            for (int i = 0; i < 104; i++) {
                bytIn[i] = (byte) fis.read();
            }
            // 解密
            byte[] bytOut = Decrypt3DES(bytIn, key);
            System.out.println(bytOut.length);
            logger.info("The decryption operation is underway");

            File fileOut = new File(fileOutName);
            fileOutStream = new FileOutputStream(fileOut);
            for (int i = 0; i < bytOut.length; i++) {
                fileOutStream.write((int) bytOut[i]);
            }
            randomAccessFile = new RandomAccessFile(fileOut, "rwd");
            randomAccessFile.seek(bytOut.length);

            fileInputStream = new FileInputStream(fileIn);
            fileInputStream.skip(104);
            byte[] buffer = new byte[1024 * 1024];
            int len = fileInputStream.read(buffer);
            while (len != -1) { // 从输入流中读取数据写入到文件中
                fileOutStream.write(buffer, 0, len);
                len = fileInputStream.read(buffer);
            }
            logger.info("decrypt video is success");
            fileInputStream.close();
            randomAccessFile.close();
            fis.close();
            fileOutStream.close();
        } catch (Exception e) {
            logger.info("Decryption error");
        }

    }

    /**
     * 3des解码
     *
     * @param value 待解密字符串
     * @param key   原始密钥字符串
     * @return
     * @throws Exception
     */
    public static byte[] Decrypt3DES(byte[] value, String key) throws Exception {
        byte[] b = decryptMode(GetKeyBytes(key), value);
        return b;
    }

    /**
     * 3des加密
     *
     * @param value 待加密字符串
     * @param key   原始密钥字符串
     * @return
     * @throws Exception
     */
    public static byte[] Encrypt3DES(byte[] value, String key) throws Exception {
        return encryptMode(GetKeyBytes(key), value);
    }

    /**
     * 计算24位长的密码byte值,首先对原始密钥做MD5算hash值，再用前8位数据对应补全后8位
     *
     * @param strKey 密钥
     * @return
     * @throws Exception
     */
    public static byte[] GetKeyBytes(String strKey) throws Exception {
        if (null == strKey || strKey.length() < 1)
            throw new Exception("key is null or empty!");
        MessageDigest alg = MessageDigest.getInstance("MD5");
        alg.update(strKey.getBytes());
        byte[] bkey = alg.digest();
        int start = bkey.length;
        byte[] bkey24 = new byte[24];
        for (int i = 0; i < start; i++) {
            bkey24[i] = bkey[i];
        }
        for (int i = start; i < 24; i++) {// 为了与.net16位key兼容
            bkey24[i] = bkey[i - start];
        }
        return bkey24;
    }

    /**
     * 加密
     *
     * @param keybyte 为加密密钥
     *                ，长度为24字节
     * @param src     为被加密的数据缓冲区（源）
     * @return
     */
    public static byte[] encryptMode(byte[] keybyte, byte[] src) {
        try {
            // 生成密钥
            SecretKey deskey = new SecretKeySpec(keybyte, Algorithm); // 加密
            //偏移量
            IvParameterSpec iv = new IvParameterSpec("12345678".getBytes());
//            Cipher c1 = Cipher.getInstance(Algorithm);
            Cipher cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, deskey, iv);
            return cipher.doFinal(src);
        } catch (NoSuchAlgorithmException e1) {
            e1.printStackTrace();
        } catch (NoSuchPaddingException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        return null;
    }

    /**
     * 解密
     *
     * @param keybyte 解密密钥，长度为24字节
     * @param src     解密后的缓冲区
     * @return
     */
    public static byte[] decryptMode(byte[] keybyte, byte[] src) {
        try {
            // 生成密钥
            SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);
            // 偏移量
            IvParameterSpec iv = new IvParameterSpec("12345678".getBytes());
            // 解密
//            Cipher c1 = Cipher.getInstance(Algorithm);
            Cipher cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, deskey, iv);
            return cipher.doFinal(src);
        } catch (NoSuchAlgorithmException e1) {
            e1.printStackTrace();
        } catch (NoSuchPaddingException e2) {
            e2.printStackTrace();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
        return null;
    }

}

