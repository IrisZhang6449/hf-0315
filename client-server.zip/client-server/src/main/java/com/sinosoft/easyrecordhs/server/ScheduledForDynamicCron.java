package com.sinosoft.easyrecordhs.server;

import com.sinosoft.easyrecordhs.controller.RequestController;
import com.sinosoft.easyrecordhs.service.UploadService;
import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author SunYu
 * @date 2018/8/24 14:35
 * <p>
 * 定时上传视频，根据配置文件里设定时间定时触发
 */
@Service
public class ScheduledForDynamicCron implements SchedulingConfigurer {
    private static Logger logger = LoggerFactory.getLogger(ScheduledForDynamicCron.class);

    @Autowired
    private UploadService uploadService;

    private volatile boolean flag = true;
    //定时
    private String task = Hs.prooerties.get(Hs.UPPLOADTASK);

    @Scheduled(fixedDelay = 1000)
    public void upload() {
        deleteOldVideo();
        if (flag) {
            logger.info("====上传未开始===={}", flag);
            return;
        }
        logger.info("+++++++" + Thread.currentThread().getName());
        logger.info("===scheduled for upload zip=={}", flag);
        Map map = new HashMap<>();
        map.put("officeCode", Hs.prooerties.get(Hs.OFFICECODE));
        map.put("bankCode", Hs.prooerties.get(Hs.BANKCODE));
        String response = HttpUtil.doPost(Hs.prooerties.get(Hs.SERVERIP) + "/easyRecordHS/upload/first", JSONObject.valueToString(map));
        logger.info("上传请求返回值：{}", response);
        if (response == null || response.contains("false")) {
            logger.info("无文件上传");
            flag = true;
            return;
        }
        uploadService.upload(response);
        logger.info("上传结束");
    }

    @Scheduled(cron = "0 0 6 * * ?")
    public void updateFalg() {
        flag = true;
        logger.info("+++++上传定时任务结束+++++++");
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        String[] uploadTask = task.split("/");
        for (int i = 0; i < uploadTask.length; i++) {
            int finalI = i;
            taskRegistrar.addTriggerTask(() -> {
                flag = false;
                logger.info("+++++++" + Thread.currentThread().getName());
                logger.info("======上传定时任务开始======{}", flag);
            }, (triggerContext) -> {
                // 定时任务触发，可修改定时任务的执行周期
                CronTrigger trigger = new CronTrigger(uploadTask[finalI]);
                Date nextExecDate = trigger.nextExecutionTime(triggerContext);
                return nextExecDate;
            });
            logger.info("开始创建定时任务 ==> {}", uploadTask[i]);
        }
    }

    /**
     * 删除视频详情页面回看视频
     * 解密后的原片
     */
    private void deleteOldVideo() {
        try {
            Iterator<Object> it = RequestController.videoList.iterator();
            while (it.hasNext()) {
                String path = it.next().toString();
                File file = new File(path);
                boolean flag = file.delete();
                if (flag) {
                    RequestController.videoList.remove(path);
                }
            }
        } catch (Exception e) {
            logger.info("delete oldVideo error:{}", e);
        }
    }
}
