package com.sinosoft.easyrecordhs.config;

import com.sinosoft.easyrecordhs.crash.CrashLogTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 客户端启动后执行的任务
 */
@Component
public class CrashLogStartUp implements ApplicationRunner {

    @Autowired
    CrashLogTask crashLogTask;
    private static Logger logger = LoggerFactory.getLogger(Logger.class);

    @Override
    public void run(ApplicationArguments args) throws Exception {
         try {
             logger.info("error日志文件上传。。。");
             crashLogTask.sendErrorLogToServer();
         }catch (Exception e){
             logger.info("传输崩溃日志异常信息："+e.getMessage());
         }
    }
}
