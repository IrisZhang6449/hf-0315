package com.sinosoft.easyrecordhs.config;

import net.jimmc.jshortcut.JShellLink;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.io.File;

/**
 * 程序第一次启动的时候再系统的启动目录下创建应用的快捷方式，让程序随系统开机自启
 * 目前请让 jsshortcut.dll文件和应用程序在同级目录
 */
@Component
public class LinkFileStartUp implements ApplicationRunner{

    private static Logger logger = LoggerFactory.getLogger(Logger.class);

    @Override
    public void run(ApplicationArguments args) throws Exception {
        /* 获取系统的自启目录 */
        String startFolder = "";
        String osName = System.getProperty("os.name");
        String userHome = System.getProperty("user.home");
        if (osName.equals("Windows 7") || osName.equals("Windows 8") || osName.equals("Windows 10")
                || osName.equals("Windows Server 2012 R2") || osName.equals("Windows Server 2014 R2")
                || osName.equals("Windows Server 2016")) {
            startFolder = userHome
                    + "\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup";
        }
        String savePath = startFolder;
        String appName = "easyrecordHS.exe";
        String relativelyPath=System.getProperty("user.dir");
        // 设置 jshortcut.dll 文件的路径，设置为与当前应用同级目录
        System.setProperty("JSHORTCUT_HOME",relativelyPath);
        String exePath = relativelyPath+File.separator+"easyrecordHS.exe";
        logger.info("系统自启目录：{}",startFolder);
        logger.info("exe文件路径：{}",exePath);

        File file = new File(savePath+appName);
        if (file.exists()){
            //如果快捷方式存在就删除之前的
            file.delete();
        }
        /* 创建快捷方式到系统启动目录 */
        boolean linkFileRet = createLinkFile(savePath, appName, exePath);
        logger.info("快捷方式创建结果：{}",linkFileRet);
    }

    /**
     *  为指定文件创建快捷方式到指定目录下，指定文件名称为英文名称，中文会导致执行无效
     * @param savePath
     * @param lnkName
     * @param exePath
     * @return
     */
    public static boolean createLinkFile(String savePath, String lnkName, String exePath){

        File exeFile = new File(exePath);
        File saveDir = new File(savePath);
        if (!exeFile.exists() || !saveDir.exists()){
            System.out.println("路径或者文件为空。");
            return false;
        }
        try {
            JShellLink link = new JShellLink();
            link.setName(lnkName);//快捷方式的名称
            link.setFolder(savePath);//存放路径
            link.setPath(exePath);//指向的exe
            link.save();
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

}
