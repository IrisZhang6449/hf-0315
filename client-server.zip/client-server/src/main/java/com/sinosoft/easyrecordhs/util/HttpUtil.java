package com.sinosoft.easyrecordhs.util;

import com.sinosoft.easyrecordhs.server.Hs;
import org.apache.http.*;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 10:20
 * 模拟http请求
 */

public class HttpUtil {
    private static Logger logger = LoggerFactory.getLogger(HttpUtil.class);
    /**
     * 上传文件到服务器上面
     * @param files 本地文件绝对路径
     * @return 发送是否成功
     * @throws IOException
     */
    public static boolean upload(JSONArray files,String contNo) {
        String url=Hs.prooerties.get(Hs.SERVERIP) +"/easyRecordHS/img/uploadLocal";
        System.out.println(url);
        //HttpClient client = createSSLClientDefault();// 开启一个客户端 HTTP 请求
        HttpClient client = createSSLClientDefault();
        HttpPost post = new HttpPost(url);//创建 HTTP POST 请求
        RequestConfig requestConfig =RequestConfig.custom()
                .setConnectTimeout(5000).setConnectionRequestTimeout(5000).setSocketTimeout(5000).build();
        post.setConfig(requestConfig);
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.setCharset(Charset.forName("UTF-8"));//设置请求的编码格式
        builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);//设置浏览器兼容模式
        for (int i = 0; i < files.length(); i++) {
            File file = new File(files.getString(i));
            builder.addBinaryBody(file.getName(), file);
        }
        builder.addTextBody("contNo",  contNo);
        builder.addTextBody("size", files.length() + "");
        HttpEntity entity = builder.build();// 生成 HTTP POST 实体
        post.setEntity(entity);//设置请求参数
        HttpResponse response = null;
        String message = "";
        try {
            response = client.execute(post);// 发起请求 并返回请求的响应
            message = getResponseMessage(response);
        } catch (Throwable tb) {
            logger.info(tb.getMessage());
            return false;
        }
        if (response.getStatusLine().getStatusCode() == 200 || message.equals("false")) {
            return true;
        } else {
            logger.info(message);
            return false;
        }
    }


    /**
     * 模拟发送 post 请求
     */
    public static String doPost(String url, String data) {
        //构建POST请求   请求地址请更换为自己的。
        HttpPost post = new HttpPost(url);
        RequestConfig requestConfig =RequestConfig.custom()
                .setConnectTimeout(3000).setConnectionRequestTimeout(3000).setSocketTimeout(3000).build();
        post.setConfig(requestConfig);
        InputStream inputStream = null;
        String result="";
        try {
            CloseableHttpClient httpClient = createSSLClientDefault();
            // 构造消息头
            post.setHeader("Content-type", "application/json; charset=utf-8");
            post.setHeader("Connection", "Close");
            // 构建消息实体
            StringEntity entity = new StringEntity(data, Charset.forName("UTF-8"));
            entity.setContentEncoding("UTF-8");
            // 发送Json格式的数据请求
            entity.setContentType("application/json");
            post.setEntity(entity);
            //发送请求
            HttpResponse response = httpClient.execute(post);
             result=getResponseMessage(response);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

    /**
     * 根据响应流获取响应消息
     *
     * @param response
     * @return
     */
    public static String getResponseMessage(HttpResponse response) {
        InputStream inputStream = null;
        String body = "";
        StringBuffer result = new StringBuffer();
        HttpEntity entityReaponse = response.getEntity();
        if (entityReaponse != null) {
            try {
                inputStream = entityReaponse.getContent();
                //转换为字节输入流
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, Consts.UTF_8));
                while ((body = br.readLine()) != null) {
                    result.append(body);
                }
            } catch (Throwable tb) {
                return "false";
            }
        }
        return result.toString();
    }

    /**
     * get请求
     */
    public static String doGet(String url) {
        try {
            CloseableHttpClient httpClient = createSSLClientDefault();
            //发送get请求
            HttpGet request = new HttpGet(url);
            HttpResponse response = httpClient.execute(request);

            /**请求发送成功，并得到响应**/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /**读取服务器返回过来的json字符串数据**/
                String strResult = EntityUtils.toString(response.getEntity());

                return strResult;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static CloseableHttpClient createSSLClientDefault() {
        try {
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
                // 信任所有
                @Override
                public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                    return true;
                }
            }).build();
            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
            return HttpClients.custom().setSSLSocketFactory(sslsf).build();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return HttpClients.createDefault();

    }

}
