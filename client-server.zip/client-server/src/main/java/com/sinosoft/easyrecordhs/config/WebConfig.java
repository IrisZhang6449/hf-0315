package com.sinosoft.easyrecordhs.config;

import com.sinosoft.easyrecordhs.server.Hs;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @Date 2019/4/12 13:14
 * @Created by LeeJunMing
 */
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

    @Override
    //设置图片、附件的映射路径
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/video/**").addResourceLocations("file:" + Hs.prooerties.get(Hs.VIDEOPATH));
        super.addResourceHandlers(registry);
    }

    //添加过滤器,拦截失效的下载链接
    @Bean
    public FilterRegistrationBean registFilter() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new URLFilter());
        registration.addUrlPatterns("/video/*");
        registration.setName("URLFilter");
        registration.setOrder(1);
        return registration;
    }

}
