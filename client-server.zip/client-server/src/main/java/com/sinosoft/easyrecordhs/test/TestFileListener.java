//package com.sinosoft.easyrecordhs.test;
//
//import com.sinosoft.easyrecordhs.service.FileDirListener;
//import org.apache.commons.io.monitor.FileAlterationMonitor;
//import org.apache.commons.io.monitor.FileAlterationObserver;
//
//public class TestFileListener {
//    public static void main(String[] args) {
//        //监控目录
//        String dir = "D:\\watchDIr";
//        //扫描间隔 毫秒值
//        long interval = 500L;
//        FileAlterationObserver observer = new FileAlterationObserver(dir,null,null);
//        observer.addListener(new FileDirListener());
//        FileAlterationMonitor monitor = new FileAlterationMonitor(interval,observer);
//        try {
//            monitor.start();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
