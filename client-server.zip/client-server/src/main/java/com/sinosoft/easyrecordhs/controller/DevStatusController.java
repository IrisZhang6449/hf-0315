package com.sinosoft.easyrecordhs.controller;
import com.sinosoft.easyrecordhs.server.Hs;
import com.sinosoft.easyrecordhs.util.HttpUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class DevStatusController {

    private static Logger logger = LoggerFactory.getLogger(Logger.class);

    private String serverIP=Hs.prooerties.get(Hs.SERVERIP);
    private String officeCode = Hs.prooerties.get(Hs.OFFICECODE);
    private String bankCode = Hs.prooerties.get(Hs.BANKCODE);

    /**
     * 高拍仪初始化状态监测
     * @param status
     * @return
     */
    @RequestMapping("/devstatus")
    public String getDevStatus(@RequestParam("devstatus") String status){
        String url = serverIP+"/easyRecordHS/clientmonitor/devstatus";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("devstatus",status);
        jsonObject.put("officeCode",officeCode);
        jsonObject.put("bankCode",bankCode);
        try {
            HttpUtil.doPost(url, jsonObject.toString());
        }catch (Exception e){
            logger.info("请求失败："+e.getMessage());
        }
        return "OK";
    }

    /**
     * 录像设备状态
     * @param videoDevStatus
     * @return
     */
    @RequestMapping("/videoRecode")
    public String getVideoDevStatus(@RequestParam("videoDevStatus") String videoDevStatus){
        String url = serverIP+"/easyRecordHS/clientmonitor/videoDevStatus";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("officeCode",officeCode);
        jsonObject.put("videoDevStatus",videoDevStatus);
        jsonObject.put("bankCode",bankCode);
        try {
            HttpUtil.doPost(url, jsonObject.toString());
        }catch (Exception e){
            logger.info("请求失败："+e.getMessage());
        }

        return "OK";
    }

    /**
     * 录音设备状态
     * @param microphoneStatus
     * @return
     */
    @RequestMapping("/microphone")
    public String microphoneStatus(@RequestParam("microphoneStatus") String microphoneStatus){
        String url = serverIP+"/easyRecordHS/clientmonitor/microphone";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("officeCode",officeCode);
        jsonObject.put("microphoneStatus",microphoneStatus);
        jsonObject.put("bankCode",bankCode);
        try {
            HttpUtil.doPost(url, jsonObject.toString());
        }catch (Exception e){
            logger.info("请求失败："+e.getMessage());
        }
        return "OK";
    }

}
