package com.sinosoft.easyrecordhs.test;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class GetLocalIpTest {

    public static void main(String[] args) throws IOException {

//        System.out.println(getLocalIPbyCMD());
        System.out.println(InetAddress.getLocalHost().getHostName());
        Socket socket = new Socket();
        SocketAddress sa = new InetSocketAddress("charberming",15999);
        socket.bind(sa);
        System.out.println(socket.getLocalSocketAddress());


    }


    /**
     * 通过执行 ipconfig 命令获取ip地址
     * @return
     */
    /*
    public static String getLocalIPbyCMD(){
        String localIP=null;
        Runtime runtime = Runtime.getRuntime();
        Process process = null;
        try {
            process = runtime.exec("ipconfig");
        } catch (IOException e) {
            e.printStackTrace();
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
        String line;
        try {
            while((line=br.readLine())!=null){
                if (line.contains("IPv4")){
                    System.out.println("客户端的IPv4相关信息："+line);
                    localIP = line.split(":")[1].trim();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (br!=null) br=null;
            if (localIP==null||"".equals(localIP)||localIP.split("\\.").length!=4){
                System.out.println("客户端本地ip获取有误："+localIP);
                return null;
            }else {
                return localIP;
            }
        }
    }
    */
}
